import 'package:flutter/material.dart';

class Roadmap extends StatelessWidget {
  const Roadmap({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
